# MP4 Game In Class 14

序言：此项目通过对班级活动照片的筛选和剪辑，